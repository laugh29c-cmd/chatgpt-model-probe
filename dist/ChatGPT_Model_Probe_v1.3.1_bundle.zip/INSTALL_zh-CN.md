# ChatGPT Model Probe v1.3.1｜安装与使用

1. Chrome 安装 Tampermonkey（油猴）。
2. Chrome → 扩展程序 → Tampermonkey → 详细信息 → 打开「允许用户脚本 / Allow User Scripts」。
3. Tampermonkey → Dashboard → 添加新脚本，删除默认内容，粘贴 `ChatGPT_Model_Slug_Probe.user.js` 全文并保存。
4. 回到 `https://chatgpt.com/`，整页刷新。
5. 页面出现 `ChatGPT metadata · v1.3.1` 悬浮窗即表示注入成功。顶部可拖动，右侧可收起/展开。
6. 正常发送一条消息，等待回复结束后查看：
   - requested (body.model)
   - message.model_slug
   - resolved_model_slug
   - server STE model_slug

`server STE model_slug` 来自 SSE 的 `server_ste_metadata.metadata.model_slug`。它是服务器向浏览器暴露的 metadata，不是底层 inference worker 的密码学证明。

脚本不上传 telemetry、不要求 API token、不持久化聊天正文；localStorage 只保存悬浮窗位置和折叠状态。

完整说明见仓库 `docs/INSTALL_zh-CN.md`。
